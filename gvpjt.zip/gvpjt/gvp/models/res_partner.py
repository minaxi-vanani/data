
# -*- coding: utf-8 -*-

from odoo import fields, models, api

class ResPartner(models.Model):
    _inherit = "res.partner"




    name = fields.Char()
    current_position = fields.Char('Current Position')
    education_ids = fields.One2many('education', 'partner_id')
    experience_ids = fields.One2many('experience', 'partner_id')
    skills_ids = fields.Many2many('skill' ,string="Skill name")


    # @api.model
    # def search_details(self, domain, fields, model, limit=None):
    #     print("\n\n\n------",self.env[model].sudo().search_read(domain, fields, limit))
    #     import pdb;pdb.set_trace()

    #     return self.env[model].sudo().search_read(domain, fields, limit)

   
    def get_partner_data(self):
        return {
            'countryData': self.env['res.country'].search_read([], ['name']),
            'stateData': self.env['res.country.state'].search_read([], ['name', 'country_id'])
        }