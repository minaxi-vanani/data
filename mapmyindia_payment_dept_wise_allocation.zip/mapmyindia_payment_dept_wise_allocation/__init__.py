# -*- coding: utf-8 -*-
# ID: 3128998

# Update Confirm button and set attrs (Studio View)
# <button name="690" class="oe_highlight" string="Confirm" type="action" attrs="{'invisible': ['|', '|', ('payment_type', '=', 'transfer'), ('state', '!=', 'draft'), ('x_payment_approval_status', '=', 'approved')]}" confirm="Please make sure you have selected correct Journal!"/>
