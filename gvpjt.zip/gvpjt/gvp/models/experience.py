# -*- coding: utf-8 -*-

import calendar
from odoo import models, fields

class GvpEducation(models.Model):
    _name = 'experience'

    def _get_year(self):
        "return :list of tuple with year"
        return [(str(year), str(year)) for year in range(1960, 2400)]

    def get_month(self):
        "return :list of tuple with month name"
        return [(
            calendar.month_abbr[month_nbr], calendar.month_name[month_nbr])
            for month_nbr in range(1, 13)
        ]

    partner_id = fields.Many2one('res.partner')
    title = fields.Char('Experience Title')
    employee_type = fields.Char('Employee Type')
    compny_name = fields.Char('Company Name')
    location = fields.Text()
    start_year = fields.Selection(selection=_get_year, string="From Year")
    end_year = fields.Selection(selection=_get_year, string="To Year")
    start_month = fields.Selection(selection=get_month, string="From Month")
    end_month = fields.Selection(selection=get_month, string="To Month")
    description = fields.Text()
