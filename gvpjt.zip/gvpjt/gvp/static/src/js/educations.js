odoo.define('gvp.education', function (require) {
    'use strict';
    
    const ajax = require('web.ajax');
    const core = require('web.core');
    const Dialog = require('web.Dialog');
    const publicWidget = require('web.public.widget');
    
    const QWeb = core.qweb;
    const _t  = core._t;
    require('web.dom_ready');
    
    
    publicWidget.registry.GVPEducation = publicWidget.Widget.extend({
        template: 'gvp.add_education',
        selector: '#education',
        xmlDependencies: ['/gvp/static/src/xml/gvp_template_view.xml'],
        events: {
            'click #edit_gvp_education': '_onClickEdit',
            'click #edit_gvp_education_update': '_onClickEditUpdate',
        },
         /**
             * @override
         */
        willStart: function () {
            var self = this;
            return $.when(this._super.apply(this, arguments));
    
        },
    
    
        start: async function() {
            var def = this._super.apply(this, arguments);
            await this.updateEducations();
            
            return def;
        },
    
        updateEducations: async function() {
            this.educationData = await this._rpc({
                route: '/my/get/educations'
            });
        },
        _select2Wrapper: function (placeholder, fetchFNC) {
            return {
                multiple: false,
                width: '100%',
                placeholder: placeholder,
                maximumInputLength: 45,
                minimumInputLength: 2,
                maximumSelectionSize: 5,
                allowClear: true,
                formatNoMatches: false,
                selection_data: false,
                fetch_rpc_fnc: fetchFNC,
                formatSelection: function (data) {
                    if (data.tag) {
                        data.text = data.tag;
                    }
                    return data.text;
                },
                fill_data: function (query, data) {
                    var that = this,
                        tags = {results: []};
                    _.each(data, function (obj) {
                        if (that.matcher(query.term, obj.name)) {
                            tags.results.push({id: obj.id, text: obj.name, isNew: false});
                        }
                    });
                    query.callback(tags);
                },
                createSearchChoice: function (term, data) {
                    var addedTags = $(this.opts.element).select2('data');
                    if (_.filter(_.union(addedTags, data), function (tag) {
                        return tag.text.toLowerCase().localeCompare(term.toLowerCase()) === 0;
                    }).length === 0) {
                        return {
                            id: _.uniqueId('_') + $.trim(term),
                            create: true,
                            teg: term,
                            text: $.trim(term),
                            isNew: true,
                        };
                    }
                },
                query: function (query) {
                    var that = this;
                    // fetch data only once and store it
                    if (!this.selection_data) {
                        this.fetch_rpc_fnc().then(function (data) {
                            that.fill_data(query, data);
                            that.selection_data = data;
                        });
                    } else {
                        this.fill_data(query, this.selection_data);
                    }
                },
                formatResult: function (term) {
                    if (term.isNew) {
                        return '<span class="badge badge-primary">New</span> ' + _.escape(term.text);
                    } else {
                        return _.escape(term.text);
                    }
                },
                // Take default tags from the input value
                initSelection: function (element, callback) {
                    debugger;
                        var data = {id: self.getParent().data.settings.default_project_id, name : self.get_project_name(self.getParent().data.settings.default_project_id)};
                    callback(data);
                },
            }
        },
         /**
         * @private
         */
        _getYear: function (startyear, endYear) {
            var years = [];
            var year_lists = [];
            endYear = endYear || moment().year();
            startyear = startyear || 1960;
            while ( startyear <= endYear ) {
                years.push(startyear++);
            }
            _.each(_.object(years, years), function (index, value) {
                year_lists.push({id: index.toString(), name: value.toString()});
            });
            return year_lists.reverse();
        },
    
        _getMonth: function(){
            var month_lists = [];
            _.each(_.object(moment.months(), moment.monthsShort()), function (index, value) {
                month_lists.push({id: index, name: value});
            });
            return month_lists;
        },
        _getValue: function () {
            return {
                'id' : this.dialog.$el.find('#id').val(),
                'school': this.dialog.$el.find('#school').val(),
                'educations': this.dialog.$el.find('#name').val(),
                'percentage': this.dialog.$el.find('#percentage').val(),
                'field_of_study': this.dialog.$el.find('#field_of_study').val(),
                'start_month': this.dialog.$el.find('#start_month').val(),
                'start_year': this.dialog.$el.find('#start_year').val(),
                'end_month': this.dialog.$el.find('#end_month').val(),
                'end_year': this.dialog.$el.find('#end_year').val(),
                'description': this.dialog.$el.find('#description').val(),
            };
        },
    
        _onClickEdit: async function (ev) {
            const self = this;
            const GetYear = this._getYear();
            const GetMonth = this._getMonth();
            var educatino = ev.currentTarget.dataset

            var educatinoDetail = {
                id :educatino.id,
                name : educatino.name,
                field_of_study : educatino.field_of_study,
                percentage : educatino.percentage,
                start_year : educatino.start_year,
                end_year : educatino.end_year,
                college : educatino.college,
                school : educatino.school,
                description : educatino.description,
                start_month : educatino.start_month,
                end_month : educatino.end_month
            }
            this.dialog = new Dialog(this, {
                $content: $(QWeb.render('gvp.education_form', {
                    eduDetails: educatinoDetail,
                    GetYear : GetYear,
                    GetMonth: GetMonth,
                })),
                buttons: [{
                    classes: 'btn-primary float-right',
                    text: 'Submit',
                    close: true,
                    click: async () => {
                        const parms = this._getValue()
                        await this._rpc({
                            route: '/my/update/educations',
                            params: parms
                        });
                        window.location.reload();
                    }
                }, {
                    classes: 'btn-secondary float-right',
                    close: true,
                    text: _t('Close'),
                }],
                size: "large",
                title: _t("Add Education"),
            }).open();
            this.dialog.opened(() => {
                this.dialog.$el.find('#education_ids').select2(
                    this._select2Wrapper(
                        _t('Ex: Test'),
                        () => {
                            return this._rpc({
                                model: 'res.partner',
                                method: 'search_read',
                                fields: ['id', 'name', 'company_type'],
                                domain: [],
                            });
                        }
                    )
                );
            });
        },

        _onClickEditUpdate: async function (ev) {
            const self = this;
            const GetYear = this._getYear();
            const GetMonth = this._getMonth();
            var educatino = ev.currentTarget.dataset

            var educatinoDetail = {
                id :educatino.id,
                name : educatino.name,
                field_of_study : educatino.field_of_study,
                percentage : educatino.percentage,
                start_year : educatino.start_year,
                end_year : educatino.end_year,
                college : educatino.college,
                school : educatino.school,
                description : educatino.description,
                start_month : educatino.start_month,
                end_month : educatino.end_month
            }
            this.dialog = new Dialog(this, {
                $content: $(QWeb.render('gvp.education_form', {
                    eduDetails: educatinoDetail,
                    GetYear : GetYear,
                    GetMonth: GetMonth,
                })),
                buttons: [

                {
                    classes: 'btn-primary float-right',
                    text: 'Update',
                    close: true,
                    click: async () => {
                        const parms = this._getValue()
                        await this._rpc({
                            route: '/my/update/educations',
                            params: parms
                        });
                        window.location.reload();
                    }
                },{
                    classes: 'btn-secondary float-right',
                    close: true,
                    text: _t('Close'),
                },{
                    classes: 'btn-secondary float-left',
                    text: 'Delete',
                    close: true,
                    click: async () => {
                    const edu_id = this.dialog.$el.find('#id').val();
                    const parms = {id:edu_id}
                        await this._rpc({
                            route: '/my/delete/educations',
                            params: parms,
                        });
                        window.location.reload();
                    }
                },],
                size: "large",
                title: _t("Edit Education"),
            }).open();
            this.dialog.opened(() => {
                this.dialog.$el.find('#education_ids').select2(
                    this._select2Wrapper(
                        _t('Ex: Test'),
                        () => {
                            return this._rpc({
                                model: 'res.partner',
                                method: 'search_read',
                                fields: ['id', 'name', 'company_type'],
                                domain: [],
                            });
                        }
                    )
                );
            });
        },

     });
});
    
