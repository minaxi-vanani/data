# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
{
    #information
    'name': 'Gvp Csaa',
    'summary':'Gvp Csaa',
    'description':'Gvp Csaa',
    'category': 'sales',

    # Dependency
    'data': [
        'security/ir.model.access.csv',
        'views/gvp_portal_menu.xml',
        'views/res_partner_view.xml',
        'views/skill_view.xml',
        'views/education_view.xml',
        'views/experience_view.xml',
        'views/gvp_portal_templates.xml',

    ],
    'assets': {
        'web.assets_frontend': [
            'gvp/static/src/js/skill.js',
            'gvp/static/src/js/experience.js',
            'gvp/static/src/js/educations.js',
            'gvp/static/src/js/profile.js',
        ],
        'web.assets_qweb': [
            'gvp/static/src/xml/*.xml',
        ],
    },
    'depends': [
        'account',
        'contacts',
        'website'
    ],

    # Other
    'installable': True,
    'auto_install': False,
    'application': True,
    'license': 'LGPL-3',
}
