odoo.define('gvp.skills', function (require) {
    'use strict';
    
    
    const ajax = require('web.ajax');
    const core = require('web.core');
    const Dialog = require('web.Dialog');
    const publicWidget = require('web.public.widget');
    
    const QWeb = core.qweb;
    const _t  = core._t;
    require('web.dom_ready');
    
    publicWidget.registry.GVPSkills = publicWidget.Widget.extend({
        selector: '#skills',
        xmlDependencies: ['/gvp/static/src/xml/gvp_template_view.xml'],
        events: {
            'click #edit_gvp_skills': '_onClickEdit',
            'click .o_alumni_remove_skill': '_onClickDeleteSkill',
        },
    
        start: async function() {
            var def = this._super.apply(this, arguments);
    
            await this.updateSkills();
            return def;
        },
    
        updateSkills: async function() {
            this.skillsData = await this._rpc({
                route: '/my/get/skills'
            });

        },
    
        //--------------------------------------------------------------------------
        // Private
        //--------------------------------------------------------------------------
    
    
        /**
         * Wrapper for select2 load data from server at once and store it.
         *
         * @private
         * @param {String} Placeholder for element.
         * @param {Function} Function to fetch data from remote location should return $.deferred object
         * resolved data should be array of object with id and name. eg. [{'id': id, 'name': 'text'}, ...]
         * @returns {Object} select2 wrapper object
        */
        _select2Wrapper: function (placeholder, fetchFNC) {
            return {
                tags: true,
                width: '100%',
                tokenSeparators: [',', ' ', '_'],
                placeholder: placeholder,
                maximumInputLength: 45,
                minimumInputLength: 2,
                maximumSelectionSize: 5,
                allowClear: true,
                formatNoMatches: false,
                selection_data: false,
                fetch_rpc_fnc: fetchFNC,
                formatSelection: function (data) {
                    if (data.tag) {
                        data.text = data.tag;
                    }
                    return data.text;
                },
                fill_data: function (query, data) {
                    var that = this,
                        tags = {results: []};
                    _.each(data, function (obj) {
                        if (that.matcher(query.term, obj.name)) {
                            tags.results.push({id: obj.id, text: obj.name, isNew: false});
                        }
                    });
                    query.callback(tags);
                },
                createSearchChoice: function (term, data) {
                    var addedTags = $(this.opts.element).select2('data');
                    if (_.filter(_.union(addedTags, data), function (tag) {
                        return tag.text.toLowerCase().localeCompare(term.toLowerCase()) === 0;
                    }).length === 0) {
                        return {
                            id: _.uniqueId('_') + $.trim(term),
                            create: true,
                            teg: term,
                            text: $.trim(term),
                            isNew: true,
                        };
                    }
                },
                query: function (query) {
                    var that = this;
                    // fetch data only once and store it
                    if (!this.selection_data) {
                        this.fetch_rpc_fnc().then(function (data) {
                            that.fill_data(query, data);
                            that.selection_data = data;
                        });
                    } else {
                        this.fill_data(query, this.selection_data);
                    }
                },
                formatResult: function (term) {
                    if (term.isNew) {
                        return '<span class="badge badge-primary">New</span> ' + _.escape(term.text);
                    } else {
                        return _.escape(term.text);
                    }
                },
                initSelection: function (element, callback) {
                    debugger;
                    var data = element.data('init-value');
                    if (!data) {
                        element.val('');
                    }
                    callback(data);
                },
            };
        },
    
        _onClickEdit: async function (ev) {
            const self = this;
            this.partner_id = ev.currentTarget.dataset.partner_id;
            this.partnerSkills = JSON.stringify(this.skillsData.partner_skills);
            this.dialog = new Dialog(this, {
                $content: $(QWeb.render('gvp.add_skill', {'test': this.partnerSkills})),
                buttons: [{
                    classes: 'btn-primary float-right',
                    text: 'Submit',
                    close: true,
                    click: self._add.bind(self),
    
                }, {
                    classes: 'btn-secondary float-right',
                    close: true,
                    text: _t('Close'),
                }],
                size: "medium",
                title: _t("Edit Skills"),
            }).open();
            this.dialog.opened(() => {
                this.mappedSkills = this.skillsData.skills.map((skill) => { return skill.name});
                self._setSkillIds(this.dialog.$el.find('#skills_ids'));
                setTimeout(() => {
                    this.dialog.$el.find('#skills_ids').select2('val',[])
                }, 200);
            });
        },
        /**
         * Skill management from select2
         *
         * @private
         */
         _setSkillIds: function ($content) {
            const self = this;
            $content.select2(this._select2Wrapper(_t('Add New Skills'), function (){
                return self._rpc({
                    model: 'skill',
                    method: 'search_read',
                    args: [],
                    kwargs: {
                        fields: ['name'],
                    }
                });
            }));
        },
        /**
         * @private
         */
        _getSkills: function ($content) {
            var res = [];
            var self = this;
            var datas = $('#skills_ids').select2('data');
            _.each(self.skillsData.skills, (skill) => {
                var value_is_delete = _.some(datas, (data) => {
                    return data.id == skill.id;
                });
                if (!value_is_delete) {
                    res.push([3, skill.id]);
                }
            });
            _.each(datas, function (val) {
                if (val.create) {
                    res.push([0, 0, {'name': val.text}]);
                } else {
                    res.push([4, val.id]);
                }
            });
            return res;
        },
        //--------------------------------------------------------------------------
        // Handlers
        //--------------------------------------------------------------------------
    
        _onClickDeleteSkill: function (ev) {
            ev.preventDefault();
            var skillId = $(ev.currentTarget).data('id');
            var parent = $(ev.currentTarget).parents(':eq(1)');
            this._rpc({
                model: 'res.partner',
                method: 'delete_skill',
                args : [skillId]
            }).then(function (res) {
                if (res) {
                    parent.remove();
                    return;
                }
            });
        },
    
        /**
         * @override
         * @param {Object} ev
         */
        _add: function (ev) {
            var self = this;
            debugger;
            this._rpc({
                route: '/my/update/skills',
                params: {'skills': this._getSkills(), 'partner_id': this.partner_id},
            }).then(function (data) {
                if (data.error) {
                    var $body = self.$('main.modal-body');
                    $body.find('.alert-dismissible').remove();
                    $body.prepend($('<div/>', {
                            class: 'alert alert-warning alert-dismissible',
                            text: data.error,
                    }));
                } else {
                    self.destroy();
                    window.location.reload();
                }
            });
        },
    });
    
});
    
