odoo.define('gvp.experience', function (require) {
    'use strict';
    
    const ajax = require('web.ajax');
    const core = require('web.core');
    const Dialog = require('web.Dialog');
    const publicWidget = require('web.public.widget');
    
    const QWeb = core.qweb;
    const _t  = core._t;
    
    publicWidget.registry.GVPExp = publicWidget.Widget.extend({
        selector: '#exp',
        xmlDependencies: ['/gvp/static/src/xml/gvp_template_view.xml'],
        events: {
            'click #edit_gvp_ex': '_onClickEdit',
            'click #edit_gvp_ex_update': '_onClickEditUpdate',
            'click #is_present': '_onClickCurrentCompany',
        },

        _onClickCurrentCompany: function (ev) {
            this.$el.find(".o_end_date").toggleClass('o_hidden');
        },
    
        start: async function() {
            var def = this._super.apply(this, arguments);
    
            await this.updateEexperiences();
            
            return def;
        },
    
        updateEexperiences: async function() {
            this.experiencesData = await this._rpc({
                route: '/my/get/experiences'
            });
        },
        _getValue: function () {
            return {
                'id' : this.dialog.$el.find('#id').val(),
                'title': this.dialog.$el.find('#title').val(),
                'employee_type': this.dialog.$el.find('#employee_type').val(),
                'compny_name': this.dialog.$el.find('#compny_name').val(),
                'location': this.dialog.$el.find('#location').val(),
                'start_month_ex': this.dialog.$el.find('#start_month_ex').val(),
                'startYearEx': this.dialog.$el.find('#startYearEx').val(),
                'end_month_ex': this.dialog.$el.find('#end_month_ex').val(),
                'end_year_ex': this.dialog.$el.find('#end_year_ex').val(),
                'descriptionex': this.dialog.$el.find('#descriptionex').val(),
            };
        },

        _onClickEdit: async function (ev) 
        {
            this.mode = ev.currentTarget.dataset.mode;
            const self = this;
            const GetYear = this._getYear();
            const GetMonth = this._getMonth();
            var experience = ev.currentTarget.dataset
            var experiencesDdtail ={
                id : experience.id,
                title : experience.title,
                employee_type : experience.employee_type,
                compny_name : experience.compny_name,
                location : experience.location,
                start_month_ex : experience.start_month_ex,
                startYearEx : experience.startYearEx,
                end_month_ex : experience.end_month_ex,
                end_year_ex : experience.end_year_ex,
                description : experience.description,
            }
            const buttons = [];
            if (this.mode == 'create') {
                buttons.push({
                    classes: 'btn-primary float-right',
                    text: 'Submit',
                    close: true,
                    click: async () => {

                        const parms = this._getValue()
                        await this._rpc({
                            route: '/my/update/experiences',
                            params: parms,
                        });
                        window.location.reload();
                    }
                });
            } else {
                buttons.push({
                    classes: 'btn-primary float-right',
                    text: 'Update',
                    close: true,
                    click: async () => {

                        const parms = this._getValue()
                        await this._rpc({
                            route: '/my/update/experiences',
                            params: parms,
                        });
                        window.location.reload();
                    }
                });
            }

            buttons.push({
                classes: 'btn-secondary float-right',
                close: true,
                text: _t('Close')
            })
            this.dialog = new Dialog(this, {
                $content: $(QWeb.render('gvp.experience_form', {
                    expDetail : experiencesDdtail,
                    GetYear : GetYear,
                    GetMonth: GetMonth,
                    mode: this.mode
                })),
                buttons: buttons,
                size: "medium",
                title: _t("Add Experiences"),
            }).open();
            this.dialog.opened(() => {
                var $input = self.dialog.$('#is_present');
                $input.on('change', function (event){

                    $("#to_month").toggleClass('o_hidden');

                });
                this.dialog.$el.find('select').select2();
            });
    
        },

        _onClickEditUpdate: async function (ev)
        {
            this.mode = ev.currentTarget.dataset.mode;
            const self = this;
            const GetYear = this._getYear();
            const GetMonth = this._getMonth();
            var experience = ev.currentTarget.dataset
            var experiencesDdtail ={
                id : experience.id,
                title : experience.title,
                employee_type : experience.employee_type,
                compny_name : experience.compny_name,
                location : experience.location,
                start_month_ex : experience.start_month_ex,
                startYearEx : experience.startYearEx,
                end_month_ex : experience.end_month_ex,
                end_year_ex : experience.end_year_ex,
                description : experience.description,
            }
            const buttons = [];
            if (this.mode == 'create') {
                buttons.push({
                    classes: 'btn-primary float-right',
                    text: 'Submit',
                    close: true,
                    click: async () => {

                        const parms = this._getValue()
                        await this._rpc({
                            route: '/my/update/experiences',
                            params: parms,
                        });
                        window.location.reload();
                    }
                });
            } else {
                buttons.push({
                    classes: 'btn-primary float-right',
                    text: 'Update',
                    close: true,
                    click: async () => {

                        const parms = this._getValue()
                        await this._rpc({
                            route: '/my/update/experiences',
                            params: parms,
                        });
                        window.location.reload();
                    }
                });
            }

            buttons.push({
                classes: 'btn-secondary float-right',
                close: true,
                text: _t('Close'),
            },{
                classes: 'btn-primary float-right',
                text: 'Delete',
                close: true,
                click: async () => {
                const ex_id = this.dialog.$el.find('#id').val();
                const parms = {id:ex_id}

                    await this._rpc({
                        route: '/my/delete/experiences',
                        params: parms,
                    });
                    window.location.reload();
                }
            })
            this.dialog = new Dialog(this, {
                $content: $(QWeb.render('gvp.experience_form', {
                    expDetail : experiencesDdtail,
                    GetYear : GetYear,
                    GetMonth: GetMonth,
                    mode: this.mode
                })),
                buttons: buttons,
                size: "medium",
                title: _t("Edit Experiences"),
            }).open();
            this.dialog.opened(() => {
                var $input = self.dialog.$('#is_present');
                $input.on('change', function (event){
                    $('.o_end_date').toggle(!$(event.currentTarget).prop('checked'));
                    $('#s2id_end_month_ex').toggle(!$(event.currentTarget).prop('checked'));
                });
                this.dialog.$el.find('select').select2();
            });

        },

        _getYear: function (startyear, endYear) {
            var years = [];
            var year_lists = [];
            endYear = endYear || moment().year();
            startyear = startyear || 1960;
            while ( startyear <= endYear ) {
                years.push(startyear++);
            }
            _.each(_.object(years, years), function (index, value) {
                year_lists.push({id: index.toString(), name: value.toString()});
            });
            return year_lists.reverse();
        },
    
        _getMonth: function(){
            var month_lists = [];
            _.each(_.object(moment.months(), moment.monthsShort()), function (index, value) {
                month_lists.push({id: index, name: value});
            });
            return month_lists;
        },
    
    });
 });
    
