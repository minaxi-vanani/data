
# -*- coding: utf-8 -*-

from odoo import models, fields, api

class Skill(models.Model):
    _name = 'skill'


    skill_id = fields.Many2one('res.partner')
    name = fields.Char(string="Skill Name")

class Partner(models.Model):
    _inherit = 'res.partner'

    skills_ids = fields.Many2many('skill')

    @api.model
    def delete_skill(self, skillId):
        return self.env.user.partner_id.write({'skills_ids': [(3, int(skillId))]})

