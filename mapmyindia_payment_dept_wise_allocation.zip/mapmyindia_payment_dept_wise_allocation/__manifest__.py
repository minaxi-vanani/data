# -*- coding: utf-8 -*-

{
    'name': 'Payment Allocation Department',
    'version': '13.0.0.1',
    'category': 'Customizations',
    'summary': 'Department Wise Payment Allocation',
    'description': """
Department Wise Payment Allocation on Vendor Payment
Task ID : 3128998
    """,
    'depends': [
        'account',
        'hr',
        'account_payment_custom_report',
    ],
    'data': [
        'data/res_groups.xml',
        'data/model_department_wise_allocation.xml',
        'security/ir.model.access.csv',
        'data/fields_res_company.xml',
        'data/fields_account_payment.xml',
        'data/ir_actions_server.xml',
        'data/base_automations.xml',
        'views/view_res_company.xml',
        'views/view_department_wise_payment_allocations.xml',
        'views/view_account_payment.xml',
        'views/report_account_payment_receipt.xml',
    ],
    'installable': True,
    'auto_install': False,
}
