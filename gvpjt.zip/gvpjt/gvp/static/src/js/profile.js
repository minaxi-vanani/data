odoo.define('gvp.profile', function (require) {
    'use strict';
    
    const ajax = require('web.ajax');
    const core = require('web.core');
    const Dialog = require('web.Dialog');
    const publicWidget = require('web.public.widget');
    
    require('web.dom_ready');


    const QWeb = core.qweb;
    const _t  = core._t;
    
    publicWidget.registry.GVPProfile = publicWidget.Widget.extend({
        selector: '#profile',
        xmlDependencies: ['/gvp/static/src/xml/gvp_template_view.xml'],
        events: {
            'click #edit_gvp_profile': '_onClickEdit',
            'change #country_id': '_onCountryChange',

        },
    
        init: function (el, data) {
            this._super.apply(this, arguments);
            this.partnerID = parseInt(data.partnerid);
        },
        start: async function() {
            var def = this._super.apply(this, arguments);
    
            await this.updateMyProfile();
            return def;
        },
    
        updateMyProfile: async function() {
            this.profileData = await this._rpc({
                route: '/my/get/profile'
            });
        },

    
        _onClickEdit: async function (ev)
        {
            const self = this;
            var partner = ev.currentTarget.dataset
           var args = [[['id', '=', parseInt(partner.id)]], [], 'res.partner'];

            args = [[], ["name", "id"], 'res.country'];

            const {countryData, stateData} = await self._rpc({
                model: 'res.partner',
                method: 'get_partner_data',
                args: [parseInt(partner.id)]
            })
            this.stateData = stateData;
            this.dialog = new Dialog(this, {
                size: 'large',
                $content: $(QWeb.render('gvp.profile_form', {
                    'id' : partner.id,
                    'name' :partner.name,
                    'phone' :partner.phone,
                    'current_position':partner.currentposition,
                    'street':partner.street,
                    'street2':partner.street2,
                    'city':partner.city,
                    'state_id':parseInt(partner.state_id),
                    'country_id':parseInt(partner.country_id),
                    'zip_code':partner.zip,
                    'countryData': countryData,
                    'stateData': stateData
    
                })),
                buttons: [{
                    classes: 'btn-primary float-right',
                    text: 'Submit',
                    close: true,
                    click: async () => {
                        const id = this.dialog.$el.find('#id').val();
                        const name = this.dialog.$el.find('#name').val();
                        const current_position= this.dialog.$el.find('#current_position').val();
                        const phone = this.dialog.$el.find('#phone').val();
                        // const street = this.dialog.$el.find('#street').val();
                        // const street2 = this.dialog.$el.find('#street2').val();
                        const state_id = this.dialog.$el.find('#state_id').val();
                        const country_id = this.dialog.$el.find('#country_id').val();
                        const city = this.dialog.$el.find('#city').val();
                        const zip = this.dialog.$el.find('#zip').val();
                        const summary = this.dialog.$el.find('#summary').val();

                        const parms = {
                            id:id,
                            name:name,
                            current_position: current_position,
                            phone: phone,
                            city:city,
                            zip:zip,
                            comment:summary,
                            state_id: parseInt(state_id),
                            country_id: parseInt(country_id),
                        }
                        console.log(parms)

                        debugger
                        await this._rpc({
                            route: '/my/update/profile',
                            params: parms
                        });
                        window.location.reload();
                    }
                }, {
                    classes: 'btn-secondary float-right',
                    close: true,
                    text: _t('Close'),
                }],
                size: "medium",
                title: _t("Edit profile"),
            }).open();
            this.dialog.opened(() => {
                this.dialog.$el.find('select').select2();
                this.dialog.$el.find('#country_id').on('change', (ev) => {
                const country_id = this.dialog.$el.find('#country_id').val();
                var $state_id = $("#state_id");

                $state_id.select2("destroy");

                $state_id.find("option").remove();
                $state_id.append($("<option class='form-control' value=''>Select State</option>"));

                _.each(this.stateData.filter((state) => state.country_id[0] == country_id), function (state) {
                    var opt = $("<option/>").addClass("form-control").val(state.id).text(state.name);
                    $state_id.append(opt);
                });
        $state_id.select2()
                });
            });
    
        },
        _onCountryChange: function (ev) {
            var self = this;
            var $states = this.$el.find("#state_id");
            $states.find("option").remove();
            $states.append($("<option class='form-control' value=''>Select State</option>"));
            _.each(self.states[ev.currentTarget.selectedOptions[0].getAttribute("value")], function (state) {
                var opt = $("<option/>").addClass("form-control").val(state.id).text(state.name);
                $states.append(opt);
            });
        },

    });
    });
    
