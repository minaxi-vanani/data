# -*- coding: utf-8 -*-

import re
from odoo import http
from odoo.http import request


class ContactControllerEdu(http.Controller):


    @http.route('/my/delete/educations', type='json', auth='user', website=True)
    def delete_education(self, **kwargs):
        print("\n\n\n\n-------------kwargs----------",kwargs)
        education = request.env['education'].search([('id','=',int(kwargs.get('id')))])
        return education.unlink()


    @http.route('/my/get/educations', type='json', auth='user')
    def list_education(self, **kwargs):
        print("educations----",kwargs)
        educations = request.env['education'].search_read([], ['name'])
        partner = request.env.user.partner_id
        partner_education = request.env.user.partner_id.education_ids
        return {'educations': educations, 'partner': partner, 'partner_education': partner_education.ids}


    @http.route('/my/update/educations', type='json', auth='user')
    def update_educations(self, educations_id=None, **kwargs):
        print("\n\n\n------",kwargs)
        if kwargs.get('id'):
            value = [(1, int(kwargs.get('id')), {
                'name' : kwargs.get('educations'),
                'field_of_study' : kwargs.get('field_of_study'),
                'percentage' : float(kwargs.get('percentage') or 0.00),
                'college' : kwargs.get('college'),
                'school' : kwargs.get('school'),
                'start_month' : kwargs.get('start_month'),
                'start_year' : kwargs.get('start_year'),
                'end_month' : kwargs.get('end_month'),
                'end_year' : kwargs.get('end_year'),
                'description' : kwargs.get('description'),

            })]
        else:
            value = [(0, 0, {
                'name' : kwargs.get('educations'),
                'field_of_study' : kwargs.get('field_of_study'),
                'percentage' : float(kwargs.get('percentage') or 0.00) ,
                'college' : kwargs.get('college'),
                'school' : kwargs.get('school'),
                'start_month' : kwargs.get('start_month'),
                'start_year' : kwargs.get('start_year'),
                'end_month' : kwargs.get('end_month'),
                'end_year' : kwargs.get('end_year'),
                'description' : kwargs.get('description'),
            })]

            print("\n\n\n--value------------education",value)
        return request.env.user.partner_id.write({'education_ids': value})


    @http.route('/my/edit/educataions', type='http', auth='user', website=True)
    def edit_educataions(self, **kwargs):
        educataions = request.env['educataion'].search([])
        return request.render('gvp.edit_educataions', {'educataions': educataions, 'partner': request.env.user.partner_id})
        
    @http.route('/my/submit/educataion', type='http', auth='user')
    def submit_educations(self, **kwargs):
        educations = kwargs.get('my_educations')
        if educations:
            educations = [int(educations) for skill in educations.split(',')]
            request.env.user.partner_id.write({'education_ids': educations})
        else:
            request.env.user.partner_id.write({'education_ids': False})
        return request.redirect('/my')


    @http.route('/my/get/experiences', type='json', auth='user')
    def list_exp(self, **kwargs):
        experiences = request.env['experience'].search_read([], ['title'])
        partner = request.env.user.partner_id
        partner_experience = request.env.user.partner_id.experience_ids
        return {'experiences': experiences, 'partner': partner, 'partner_experiences': partner_experience.ids}


    @http.route('/my/delete/experiences', type='json', auth='user', website=True)
    def delete_exp(self, **kwargs):
        experience = request.env['experience'].search([('id','=',int(kwargs.get('id')))])
        return experience.unlink()

    @http.route('/my/update/experiences', type='json', auth='user')
    def update_exp(self, experience_ids=None, **kwargs):
        if kwargs.get('id'):
            value = [(1, int(kwargs.get('id')), {
                'title' : kwargs.get('title'),
                'employee_type' : kwargs.get('employee_type'),
                'location' : kwargs.get('location'),
                'compny_name' : kwargs.get('compny_name'),
                'start_month' : kwargs.get('start_month_ex'),
                'start_year' : kwargs.get('startYearEx'),
                'end_month' : kwargs.get('end_month_ex'),
                'end_year' : kwargs.get('end_year_ex'),
                'description' : kwargs.get('descriptionex'),
            })]
        else:
            value = [(0, 0, {
                'title' : kwargs.get('title'),
                'employee_type' : kwargs.get('employee_type'),
                'location' : kwargs.get('location') ,
                'compny_name' : kwargs.get('compny_name'),
                'start_month' : kwargs.get('start_month_ex'),
                'start_year' : kwargs.get('startYearEx'),
                'end_month' : kwargs.get('end_month_ex'),
                'end_year' : kwargs.get('end_year_ex'),
                'description' : kwargs.get('descriptionex'),
            })]
            print("\n\n\n--value------------------exper",value)
        return request.env.user.partner_id.write({'experience_ids': value})


    @http.route('/my/edit/experiences', type='http', auth='user', website=True)
    def edit_exp(self, **kwargs):
        experiences = request.env['experiences'].search([])
        return request.render('gvp.edit_experiences', {'experiences': experiences, 'partner': request.env.user.partner_id})
        
    @http.route('/my/submit/experiences', type='http', auth='user')
    def submit_exp(self, **kwargs):
        experiences = kwargs.get('my_experiences')
        if experiences:
            experiences = [int(educations) for skill in educations.split(',')]
            request.env.user.partner_id.write({'experience_ids': educations})
        else:
            request.env.user.partner_id.write({'experience_ids': False})
        return request.redirect('/my')
